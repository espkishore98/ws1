package com.example.lmsusecase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmUseCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
