package com.example.lmsusecase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsUseCaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsUseCaseApplication.class, args);
	}

}
