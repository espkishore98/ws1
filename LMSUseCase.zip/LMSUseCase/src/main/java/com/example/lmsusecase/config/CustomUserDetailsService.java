package com.example.lmsusecase.config;

import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service("userDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

	UserDetailsService userDetailsService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		if (username == null || username.isEmpty()) {
			throw new UsernameNotFoundException("Username is empty");
		}

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		Object clientPrincipal = authentication.getPrincipal();

		if (clientPrincipal instanceof User) {

			UserDetails user = loadUserByUsername(username);
			if (user != null)
				return user;
		}

		throw new UsernameNotFoundException("Unauthorized client_id or username not found: " + username);
	}

	public CustomUserDetailsService(@Lazy UserDetailsService userDetailsService) {
		super();

		this.userDetailsService = userDetailsService;
	}

}