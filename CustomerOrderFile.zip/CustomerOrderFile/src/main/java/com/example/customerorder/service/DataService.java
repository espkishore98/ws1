package com.example.customerorder.service;

import com.example.customerorder.entity.Order;
import com.example.customerorder.entity.OrderDetails;
import com.example.customerorder.filereader.DataReader;
import com.example.customerorder.repository.OrderDetailsRepository;
import com.example.customerorder.repository.OrderRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@Service
public class DataService {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private DataReader dataReader;
    @Autowired
    private OrderDetailsRepository orderDetailsRepository;

    public String storeDetails(MultipartFile file) {
        return dataReader.readDataAndStore(file);
    }

    @Transactional
    public String storeCustomerAndOrderDetails(Order order) {
        Double orderTotal = 0.0;
        String ordName = null;
        Order savedOrder = orderRepository.save(order);
        ordName = savedOrder.getOrderName();
        for (OrderDetails orderDetails : order.getOrderDetails()) {
            orderTotal += orderDetails.getTotalAmount();
            orderDetails.setOrder(savedOrder);
            orderDetails.setOrderCreatedBy(order.getOrderName());
            orderDetails.setOrderCreatedDate(LocalDate.now());
            orderDetails.setOrderDeliveryDate(LocalDate.now().plusDays(1));
            orderDetailsRepository.save(orderDetails);
        }

        return "Order Details for the customer "+ ordName +" are saved and the Grand Total is : "+ orderTotal + " rupees";

    }
}
