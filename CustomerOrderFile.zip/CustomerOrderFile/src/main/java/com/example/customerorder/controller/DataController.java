package com.example.customerorder.controller;

import com.example.customerorder.filereader.DataReader;
import com.example.customerorder.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/customer")
public class DataController {
    @Autowired
    private DataService dataService;

    @Autowired
    private DataReader dataReader;


    @PostMapping("/orderInvoice")
    public ResponseEntity<String> orderDetails(@RequestParam("file") MultipartFile file) {
        String result = dataService.storeDetails(file);

        return ResponseEntity.ok(result);
    }
}