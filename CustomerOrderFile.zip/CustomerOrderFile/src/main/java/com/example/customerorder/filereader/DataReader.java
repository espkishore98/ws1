package com.example.customerorder.filereader;

import com.example.customerorder.entity.Order;
import com.example.customerorder.entity.OrderDetails;
import com.example.customerorder.service.DataService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Component
public class DataReader {
    private final DataService dataService;

    public DataReader(DataService dataService) {
        this.dataService = dataService;
    }

    public String readDataAndStore(MultipartFile file) {
        List<String> validationErrors = new ArrayList<>();
        String result = null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            boolean isFirstLine = true;
            Order order = null;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    line = br.readLine();
                    continue;
                }
                if (isFirstLine) {
                    isFirstLine = false;
                    order = parseOrder(line, validationErrors);
                    continue;
                }
                if (line.contains(",")) {
                    OrderDetails orderDetails = parseOrderDetails(line, validationErrors);
                    if (order != null) {
                        order.addOrderDetails(orderDetails);
                    }
                }

            }
            if (validationErrors.isEmpty()) {
                result = dataService.storeCustomerAndOrderDetails(order);
            } else {
                for (String error : validationErrors) {
                    System.out.println("Validation Error: " + error);
                }
                System.out.println("Data validation failed. Rolling back.");
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Data validation failed");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private Order parseOrder(String line, List<String> validationErrors) {
        if (line == null) {
            validationErrors.add("Invalid number of columns for order data");
            return null;
        }

        Order order = new Order();
        order.setOrderName(line.trim());

        System.out.println("Customer details: " + order.toString());
        return order;
    }

    private OrderDetails parseOrderDetails(String line, List<String> validationErrors) {
        OrderDetails orderDetails = new OrderDetails();
        String[] data = line.split(",");
        
        if (data.length != 5) {

            validationErrors.add("Invalid number of columns for order details data" + data);
            return orderDetails;
        }

        try {
            orderDetails.setItemName(data[0].trim());
            orderDetails.setItemCode(data[1].trim());
            orderDetails.setUnitPrice(Double.parseDouble(data[2].trim()));
            orderDetails.setItemQuantity(Integer.parseInt(data[3].trim()));
            orderDetails.setTotalAmount(Double.parseDouble(data[4].trim()));
        } catch (NumberFormatException e) {
            validationErrors.add("Invalid data type in order details");
        }

        System.out.println("Order details: " + orderDetails.toString());
        return orderDetails;
    }
}
