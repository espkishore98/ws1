package com.example.customerorder.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "order_details")
public class OrderDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @Column(name = "item_name")
    private String itemName;

    @Column(name = "item_code")
    private String itemCode;

    @Column(name = "unit_price")
    private Double unitPrice;

    @Column(name = "item_quantity")
    private Integer itemQuantity;

    @Column(name = "total_amount")
    private Double totalAmount;

    @Column(name = "order_created_date")
    private LocalDate orderCreatedDate;

    @Column(name = "order_created_by")
    private String orderCreatedBy;

    @Column(name = "order_delivery_date")
    private LocalDate orderDeliveryDate;

}