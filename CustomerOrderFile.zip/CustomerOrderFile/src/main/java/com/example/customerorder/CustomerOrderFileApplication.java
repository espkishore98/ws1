package com.example.customerorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerOrderFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerOrderFileApplication.class, args);
	}

}
