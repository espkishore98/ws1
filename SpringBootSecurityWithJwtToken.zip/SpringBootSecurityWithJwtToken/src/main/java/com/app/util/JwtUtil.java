package com.app.util;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

@Component
public class JwtUtil {

	
    private static final long EXPIRATION_TIME = 86400000;
    private final String secret;
    private final UserDetailsService userDetailsService;

    public JwtUtil(@Value("${app.secret}") String secret, UserDetailsService userDetailsService) {
        this.secret = secret;
        this.userDetailsService = userDetailsService;
    }

    
public String generateToken(Authentication authentication) {
    UserDetails userDetails = (UserDetails) authentication.getPrincipal();
    List<String> roles = userDetails.getAuthorities().stream()
            .map(GrantedAuthority::getAuthority)
            .collect(Collectors.toList());

    return Jwts.builder()
            .setSubject(userDetails.getUsername())
            .claim("roles", roles)
            .setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
            .signWith(SignatureAlgorithm.HS256, secret.getBytes())
            .compact();
}
	
	//read claims
	public Claims getClaims(String token) {
		
		return Jwts.parser()
				.setSigningKey(secret.getBytes())
				.parseClaimsJws(token)
				.getBody();
		
	}
	
	//read token exp date from clams
	public Date getExpDate(String token) {
		return getClaims(token).getExpiration();
		
	}
	//read subject/user which user trying to login
	public String getUserName(String token) {
		return getClaims(token).getSubject();
	}
	// validating if token is exp or not
	public boolean isTokenExp(String token) {
		Date expDate = getExpDate(token);
		return expDate.before(new Date(System.currentTimeMillis()));
	}
	//validate username in token, expDate of token
	public boolean validateToken(String token,String username) {
		String tokenUserName = getUserName(token);
		return (username.equals(tokenUserName) && !isTokenExp(token));
	}
	
}