package com.app.usercontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.app.exception.InvalidCredentialsException;
import com.app.exception.InvalidTokenException;
import com.app.userentity.User;
import com.app.userentity.UserRequest;
import com.app.userentity.UserResponse;
import com.app.userserviceimpl.UserServiceImpl;
import com.app.util.JwtUtil;

import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.SignatureException;

@RestController
public class UserController {

	@Autowired
	private UserServiceImpl userServiceImpl;

	@Autowired
	private JwtUtil util;

	// this for validating user credentials
	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/user")
	public ResponseEntity<User> saveClientDetails(@RequestBody User user) {
		System.out.println(user);
		return new ResponseEntity<User>(userServiceImpl.saveClient(user), HttpStatus.CREATED);

	}

	@PostMapping("/login")
	public ResponseEntity<UserResponse> getToken(@RequestHeader String username,
			@RequestHeader String password) {//@RequestBody UserRequest userLoginDetails
		// validate username and password
		try {
			
			UserRequest userLoginDetails=new UserRequest();
			userLoginDetails.setUsername(username);
			userLoginDetails.setPassword(password);
			Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userLoginDetails.getUsername(),
					userLoginDetails.getPassword()));
			String username1 = userLoginDetails.getUsername();
			String token = util.generateToken(authenticate);
			System.out.println("this is token generated" + token);
			
			UserResponse userResponse=new UserResponse();
			userResponse.setUsername(userLoginDetails.getUsername());
			userResponse.setMessage("user login success!");
			userResponse.setToken(token);
			return new ResponseEntity<UserResponse>(userResponse, HttpStatus.OK);

		} catch (AuthenticationException ex) {
			throw new InvalidCredentialsException("Invalid User Credentials");
		} catch (JwtException ex) {
			if (ex instanceof SignatureException) {
				throw new InvalidTokenException("Invalid Token Signature");
			} else {
				throw new InvalidTokenException("Invalid Token");
			}

		}

	}

//    @PostMapping("/login")
//    public ResponseEntity<UserResponse> getToken(@RequestBody UserRequest userLoginDetails) {
//        try {
//            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
//                    userLoginDetails.getUsername(),
//                    userLoginDetails.getPassword()
//            ));
//
//            String username = userLoginDetails.getUsername();
//            String token = util.generateToken(username);
//            System.out.println("Token generated: " + token);
//
//            UserResponse userResponse = new UserResponse();
//            userResponse.setUsername(userLoginDetails.getUsername());
//            userResponse.setMessage("User login success!");
//            userResponse.setToken(token);
//            return new ResponseEntity<>(userResponse, HttpStatus.OK);
//        } catch (BadCredentialsException ex) {
//            throw new InvalidCredentialsException("Invalid User Credentials");
//        }
//    }
}
