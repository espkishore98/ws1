package com.app.userservice;

import java.util.Optional;

import com.app.userentity.User;

public interface UserService {

	User saveClient(User user);

	Optional<User> findByName(String name);

}
