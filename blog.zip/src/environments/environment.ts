export const environment = {
  production: false,
  base8080Url : 'http://localhost:8081/api/auth/',
  base8081Url:'http://localhost:8081/api/posts/'
};
