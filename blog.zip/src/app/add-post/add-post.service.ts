import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {PostPayload} from './post-payload';
import {Observable} from 'rxjs';
import { environment } from 'src/environments/environment';

const baseUrl = environment.base8081Url

@Injectable({
  providedIn: 'root'
})
export class AddPostService {
  deletePost(permaLink: Number):Observable<any> {
    return this.httpClient.delete(baseUrl+'delete/' + permaLink , {responseType: 'text'});
  }

  constructor(private httpClient: HttpClient) {
  }

  addPost(postPayload: PostPayload){
    return this.httpClient.post(baseUrl, postPayload);
  }

  getAllPosts(): Observable<Array<PostPayload>>{
    return this.httpClient.get<Array<PostPayload>>(baseUrl+"all");
  }

  getPost(permaLink: Number):Observable<PostPayload>{
    return this.httpClient.get<PostPayload>(baseUrl+'get/' + permaLink);
  }
}

