import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {PostPayload} from './post-payload';
import {AddPostService} from './add-post.service';
import {Router} from '@angular/router';
import { LoginService } from '../authentication/login.service';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css']
})
export class AddPostComponent implements OnInit {
//bloguser =this.loginService.eemail
  bloguser =''
  addPostForm: FormGroup;
  postPayload: PostPayload;
  title = new FormControl('');
  body = new FormControl('');

  constructor(private addpostService: AddPostService, private router: Router, private loginService : LoginService) {
    this.addPostForm = new FormGroup({
      title: this.title,
      body: this.body
    });
    this.postPayload = {
      content: '',
      title: '',
      username: ''
    }
  }

  ngOnInit() {
console.log("this is loff email",this.loginService.eemail)
    this.loginService.getUsername(this.loginService.eemail).subscribe(
      (data:any)=>{
        this.bloguser=data
        console.log('this is username',data)
      },
      (_error:any)=>{
console.log('error getting username',_error)
      }
    )
  }
  uemail = this.loginService.eemail
  addPost() {

    this.postPayload.username = this.loginService.eemail
    this.postPayload.content=  this.addPostForm.get('body')?.value
    this.postPayload.title = this.addPostForm.get('title')?.value
    this.addpostService.addPost(this.postPayload).subscribe(data => {
      this.router.navigateByUrl('/');
    }, error => {
      console.log('Failure Response');
    })
  }
}
