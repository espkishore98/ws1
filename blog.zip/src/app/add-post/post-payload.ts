export class PostPayload{

  content: String | undefined;
  title: String | undefined;
  username: String | undefined
}
