import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { PostPayload } from '../add-post/post-payload';
import { AddPostService } from '../add-post/add-post.service';
import { LoginService } from '../authentication/login.service';

// @ts-ignore
@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  post!: PostPayload;
  permaLink: any;

  constructor(private router: ActivatedRoute, private postService: AddPostService, private loginService : LoginService, private route : Router) {
  }

  ngOnInit() {
    this.router.params.subscribe(params => {
      this.permaLink = params['id'];
    });

    this.postService.getPost(this.permaLink).subscribe((data:PostPayload) => {
      this.post = data;
    },(err: any) => {
      console.log('Failure Response');
    })
  }


  // editPost(){
  //   this.route.navigate(['/blog'])
  // }

  deletePost(){
    this.postService.deletePost(this.permaLink).subscribe(

    (_data:any)=>{
     console.log('deleted')
     this.route.navigate(['/blog'])
     alert('Post Deleted!')
     //window.location.reload();
    },(_error:any)=>{
      console.log('Failed to delete',_error)
    }
    )
  }


  back()
  {
    this.route.navigate(['/blog'])
  }
}
