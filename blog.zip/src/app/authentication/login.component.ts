import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { User } from './user';

@Component({
  selector: 'login-app',
  templateUrl: './login.component.html'
})

export class LoginComponent implements OnInit  {


  msg='';

  blogusers: any
  constructor(private loginService : LoginService, private router : Router) { }
  user=new User();
  ngOnInit() { }

  loginUser(){

    this.loginService.loginCheck(this.user).subscribe(
      data =>{
        console.log("response received")
        this.router.navigate(['/blog'])
      } ,
      error =>{
        console.log("exception occured");
        this.msg="Bad credentials,please enter valid email and password";

      }

      )
    }



    gotoRegister(){
    this.router.navigate(['/register'])
  }
}
