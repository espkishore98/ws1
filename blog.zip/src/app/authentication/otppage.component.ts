import { Component, OnInit, ViewChild } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'otp-page',
  templateUrl: 'otppage.component.html'
})

export class OtpPageComponent implements OnInit {
  otp=''  ;
  showOtpComponent = true;
  msg='';
  @ViewChild("ngOtpInput", { static: false }) ngOtpInput: any; config = { allowNumbersOnly: true, length: 4, isPasswordInput: false, disableAutoFocus: false, placeholder: "*", inputStyles: { width: "50px", height: "50px", }, };

  constructor(private service  : LoginService, private router : Router) { }
  myForm!: FormGroup;
  ngOnInit() {
    this.myForm = new FormGroup({
      input1: new FormControl(''),
      input2: new FormControl(''),
      input3: new FormControl(''),
      input4: new FormControl('')
    });
  }
  onSubmit(form: FormGroup) {
    console.log('Valid?', form.valid); // true or false
    //console.log('input1', form.value.input1);
    //console.log('input2', form.value.input2);
   // console.log('input3', form.value.input3);
   // console.log('input4', form.value.input4);
    const value = [`${form.value.input1}${form.value.input2}${form.value.input3}${form.value.input4}`]
  //  console.log(value)
    this.ValidateOtp(value)
  }

  ValidateOtp(value: any):void{
    console.log(value);
    this.otp=value
   // console.log(this.otp)
    //if(this.otp.length. == 1) {
    this.service.getOtp(this.otp).subscribe(
    data =>{

      console.log("response received")
      alert("Success ! Please Login to Start Writing....")
      this.router.navigate(['/login'])

    } ,
    error =>{
      alert("Error Invalid OTP")
      console.log("exception occured");
      this.msg="Bad credentials,please enter valid otp";

    }

    )
  }
 // }
}
