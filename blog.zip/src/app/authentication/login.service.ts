import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { User } from './user';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

import { JwtAutResponse } from './jwt-aut-response';
import { LocalStorageService } from 'ngx-webstorage';

const baseUrl = environment.base8080Url;

@Injectable({
  providedIn: 'root'
})
export class LoginService implements OnInit{

 blogUser =''
  constructor(private http: HttpClient, private router: Router,private localStoraqeService: LocalStorageService) { }
  ngOnInit() {

  }


  // logout() {
  //  this.session=false;
  //   window.sessionStorage.clear();
  //   this.router.navigate(['/blog'])
  // }
  eemail ='';
  un=''

  registerCheck(data: any) {
    console.log(data)
     this.eemail = data.email
     this.un= data.userName
    return this.http.post(baseUrl+'signup', data);
  }

  isAuthenticated(): boolean {
    return this.localStoraqeService.retrieve('username') != null;
  }



  logout() {
    this.localStoraqeService.clear('authenticationToken');
    this.localStoraqeService.clear('username');
  }

  loginCheck(user: User) : Observable<any> {
    return this.http.post<JwtAutResponse>(baseUrl + 'login', user).pipe(map(data => {
      console.log(" data here in logincheck"+ data.username + "and" + data.authenticationToken)
      this.localStoraqeService.store('authenticationToken', data.authenticationToken);
      this.localStoraqeService.store('username', data.username);
      return true;
    }));

    // console.log(user)
    //  this.eemail = user.email
    //  this.session=true
    // return this.http.post(baseUrl+'login', user);
  }


  getOtp(otp: any): Observable<any> {
    console.log(this.un)
    const uname= this.un
    console.log(otp)
    return this.http.get(`${baseUrl+'getOtp'}/${uname}/${otp}`);
  }

  createOtp(data: any): Observable<any> {
    console.log(data)
    return this.http.post(baseUrl+'createOtp', data);
  }

  getUsername( eemail: any): Observable<any>{
    return this.http.get(baseUrl + 'getName/' + eemail, {responseType: 'text'});

  }

}


