import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { User } from './user';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'register-app',
  templateUrl: 'register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  msg='';
  constructor(private loginService : LoginService, private router : Router) { }
 user=new User();
  ngOnInit() { }



  registerUser(){

    this.loginService.registerCheck(this.user).subscribe(
      data =>{
        console.log("response received")
        this.router.navigate(['/otppage'])
      } ,
      error =>{
        console.log("exception occured");
        this.msg="Bad credentials,please enter valid email and password";

      }

      )
    }



    gotoLogin(){
    this.router.navigate(['/login'])
  }
}
