export class User {

  id: number = 0;
email: string = '';
userName: string = '';
password: string = '';
 constructor(){

 }

}
