package com.javatechie.executor.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMultithreadingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
