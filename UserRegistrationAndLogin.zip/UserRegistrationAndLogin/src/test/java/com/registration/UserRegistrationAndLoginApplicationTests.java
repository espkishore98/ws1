package com.registration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationAndLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
