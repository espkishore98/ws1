package spring.angular.blogging.exception;
public class SpringBlogException extends RuntimeException {
    public SpringBlogException(String message) {
        super(message);
    }
}
