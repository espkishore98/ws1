import { Component } from '@angular/core';
import { LikeService } from 'src/services/like.service';

@Component({
  selector: 'app-post-like',
  templateUrl: './likes.component.html',
  styleUrls: ['./likes.component.css']
})
export class LikesComponent {
  constructor(private LikeService : LikeService) { }

  createPostLike(like: any): void {
    this.LikeService.createPostLike(like)
      .subscribe(response => {
        // Handle successful post like creation
      }, error => {
        // Handle error
      });
  }

  getPostLikeById(likeId: number): void {
    this.LikeService.getPostLikeById(likeId)
      .subscribe(like => {
        // Handle retrieved post like
      }, error => {
        // Handle error
      });
  }

  deletePostLike(likeId: number): void {
    this.LikeService.deletePostLike(likeId)
      .subscribe(response => {
        // Handle successful post like deletion
      }, error => {
        // Handle error
      });
  }
}
