import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { User } from 'src/models/user.model';

@Component({
  selector: 'app-chat',
  templateUrl: './chats.component.html',
  styleUrls: ['./chats.component.css']
})
export class ChatsComponent {
  people: User[] = [

  ];

  constructor(private dialogRef: MatDialogRef<ChatsComponent>) {}

  startChat(person: User) {
    // Logic to start a chat with the selected person
    console.log("Chat started with:", person);
    this.dialogRef.close();
  }
}




// import { Component, OnInit } from '@angular/core';
// import { ChatService } from 'src/services/chat.service';

// @Component({
//   selector: 'app-chat',
//   templateUrl: './chats.component.html',
//   styleUrls: ['./chats.component.css']
// })
// export class ChatsComponent implements OnInit {
//   chatId!: number;
//   chatMessages!: any[];

//   constructor(private chatService: ChatService) { }

//   ngOnInit(): void {
//     this.getChatMessages();
//   }

//   createChat(chat: any): void {
//     this.chatService.createChat(chat)
//       .subscribe(response => {
//         // Handle successful creation
//       }, error => {
//         // Handle error
//       });
//   }

//   getChatMessages(): void {
//     this.chatService.getChatMessages(this.chatId)
//       .subscribe(messages => {
//         this.chatMessages = messages;
//       }, error => {
//         // Handle error
//       });
//   }

//   sendChatMessage(message: any): void {
//     this.chatService.sendChatMessage(this.chatId, message)
//       .subscribe(response => {
//         // Handle successful message sending
//       }, error => {
//         // Handle error
//       });
//   }

//   deleteChatMessage(messageId: number): void {
//     this.chatService.deleteChatMessage(this.chatId, messageId)
//       .subscribe(response => {
//         // Handle successful message deletion
//       }, error => {
//         // Handle error
//       });
//   }
// }
