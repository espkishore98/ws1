import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ChatsComponent } from '../chats/chats.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
constructor(private router:Router,private dialog: MatDialog){}

addPost(){
  this.router.navigate(['/add-post'])
}

gotoNotifications(){
  this.router.navigate(['/notifications'])
}

gotoProfile(){
  this.router.navigate(['/profile'])
}
chatToggle!: HTMLElement;
chatBox!: HTMLElement;

ngOnInit() {
  this.chatToggle = document.querySelector('.chat-toggle') as HTMLElement;
  this.chatBox = document.querySelector('.chat-box') as HTMLElement;
}

toggleChatBox() {
  this.chatBox.style.display = this.chatBox.style.display === 'none' ? 'block' : 'none';
}

gotoChat(){
  this.dialog.open(ChatsComponent, {
    width: '400px'
  });

  }
}
