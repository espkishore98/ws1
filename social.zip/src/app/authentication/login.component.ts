import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/models/user.model';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'login',
  templateUrl: 'login.component.html',
  styleUrls: ['./auth.component.css']
})

export class LoginComponent implements OnInit {

  user=new User();
  msg: string='';
  transitionSuccess :boolean= false;
  constructor(private http: HttpClient, private userService : UserService, private router : Router) { }

  ngOnInit() { }

  onSubmit() {
    this.userService.getUser(this.user).subscribe(
      data =>{
        console.log(data)
        console.log("response received")
        this.router.navigate(['/home'])
      } ,
      error =>{
        console.log("Exception occured");
        this.msg="Bad credentials,please enter valid email and password";

      }

      )
    }
}
