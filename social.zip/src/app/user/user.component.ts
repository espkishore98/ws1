import { Component } from '@angular/core';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  constructor(private userService: UserService) { }

  saveUser(user: any): void {
    this.userService.saveUser(user)
      .subscribe(response => {
        // Handle successful user creation
      }, error => {
        // Handle error
      });
  }

  getAllUsers(): void {
    this.userService.getAllUsers()
      .subscribe(users => {
        // Handle retrieved users
      }, error => {
        // Handle error
      });
  }

  getUserByUsername(username: string): void {
    this.userService.getUserByUsername(username)
      .subscribe(user => {
        // Handle retrieved user
      }, error => {
        // Handle error
      });
  }

  deleteUser(userId: number): void {
    this.userService.deleteUser(userId)
      .subscribe(response => {
        // Handle successful user deletion
      }, error => {
        // Handle error
      });
  }
}
