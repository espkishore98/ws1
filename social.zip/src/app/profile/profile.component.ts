import { Component } from '@angular/core';
import { ProfileService } from 'src/services/profile.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  constructor(private profileService: ProfileService) { }

  getProfile(profileId: number): void {
    this.profileService.getProfile(profileId)
      .subscribe(profile => {
        // Handle retrieved profile
      }, error => {
        // Handle error
      });
  }

  createProfile(profile: any): void {
    this.profileService.createProfile(profile)
      .subscribe(response => {
        // Handle successful profile creation
      }, error => {
        // Handle error
      });
  }

  updateProfile(profileId: number, profile: any): void {
    this.profileService.updateProfile(profileId, profile)
      .subscribe(updatedProfile => {
        // Handle updated profile
      }, error => {
        // Handle error
      });
  }

  deleteProfile(profileId: number): void {
    this.profileService.deleteProfile(profileId)
      .subscribe(response => {
        // Handle successful profile deletion
      }, error => {
        // Handle error
      });
  }
}
