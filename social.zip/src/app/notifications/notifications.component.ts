import { Component, OnInit } from '@angular/core';
import { NotificationService } from 'src/services/notification.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notificationId!: number;
  userId!: number;
  notifications!: any[];

  constructor(private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.getNotificationsByUserId();
  }

  createNotification(notification: any): void {
    this.notificationService.createNotification(notification)
      .subscribe(response => {
        // Handle successful notification creation
      }, error => {
        // Handle error
      });
  }

  getNotificationById(): void {
    this.notificationService.getNotificationById(this.notificationId)
      .subscribe(notification => {
        // Handle successful notification retrieval
      }, error => {
        // Handle error
      });
  }

  getNotificationsByUserId(): void {
    this.notificationService.getNotificationsByUserId(this.userId)
      .subscribe(notifications => {
        this.notifications = notifications;
      }, error => {
        // Handle error
      });
  }

  deleteNotification(notificationId: number): void {
    this.notificationService.deleteNotification(notificationId)
      .subscribe(response => {
        // Handle successful notification deletion
      }, error => {
        // Handle error
      });
  }

  markNotificationAsRead(notificationId: number): void {
    this.notificationService.markNotificationAsRead(notificationId)
      .subscribe(response => {
        // Handle successful notification update
      }, error => {
        // Handle error
      });
  }
}
