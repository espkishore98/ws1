import { Component, OnInit } from '@angular/core';
import { FriendConnectionService } from 'src/services/friend-connection.service';

@Component({
  selector: 'app-friend-connection',
  templateUrl: './friend-connection.component.html',
  styleUrls: ['./friend-connection.component.css']
})
export class FriendConnectionComponent implements OnInit {
  userId!: number;
  friendId!: number;
  friendCount!: number;
  friends!: string[];

  constructor(private friendConnectionService: FriendConnectionService) { }

  ngOnInit(): void {
    this.getFriendCount();
    this.getFriends();
  }

  createFriendConnection(): void {
    this.friendConnectionService.createFriendConnection(this.userId, this.friendId)
      .subscribe(response => {
        // Handle successful friend connection creation
      }, error => {
        // Handle error
      });
  }

  deleteFriendConnection(id: number): void {
    this.friendConnectionService.deleteFriendConnection(id)
      .subscribe(response => {
        // Handle successful friend connection deletion
      }, error => {
        // Handle error
      });
  }

  getFriendCount(): void {
    this.friendConnectionService.getFriendCount(this.userId)
      .subscribe(count => {
        this.friendCount = count;
      }, error => {
        // Handle error
      });
  }

  getFriends(): void {
    this.friendConnectionService.getFriends(this.userId)
      .subscribe(friends => {
        this.friends = friends;
      }, error => {
        // Handle error
      });
  }
}
