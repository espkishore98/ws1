import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FriendConnectionComponent } from './friend-connection.component';

describe('FriendConnectionComponent', () => {
  let component: FriendConnectionComponent;
  let fixture: ComponentFixture<FriendConnectionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FriendConnectionComponent]
    });
    fixture = TestBed.createComponent(FriendConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
