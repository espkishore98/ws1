import { Component, OnInit } from '@angular/core';
import { CommentService } from 'src/services/comment.service';

@Component({
  selector: 'app-comment',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {
  commentId!: number;
  comment: any;

  constructor(private commentService: CommentService) { }

  ngOnInit(): void {
    this.getCommentById();
  }

  createComment(comment: any): void {
    this.commentService.createComment(comment)
      .subscribe(response => {
        // Handle successful comment creation
      }, error => {
        // Handle error
      });
  }

  getCommentById(): void {
    this.commentService.getCommentById(this.commentId)
      .subscribe(comment => {
        this.comment = comment;
      }, error => {
        // Handle error
      });
  }

  deleteComment(): void {
    this.commentService.deleteComment(this.commentId)
      .subscribe(response => {
        // Handle successful comment deletion
      }, error => {
        // Handle error
      });
  }
}
