import { Component, OnInit } from '@angular/core';
import { PostService } from 'src/services/post.service';
import {Post} from 'src/models/post.model'
import { Observable } from 'rxjs';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-post',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  constructor(private postService: PostService,private sanitizer: DomSanitizer) { }

  posts!: Observable<Array<Post>>;

  ngOnInit() {
    this.posts = this.postService.getAllPosts();
  }




  // savePost(post: any): void {
  //   this.postService.savePost(post)
  //     .subscribe(response => {
  //       // Handle successful post creation
  //     }, error => {
  //       // Handle error
  //     });
  // }

  // getAllPosts(): void {
  //   this.postService.getAllPosts()
  //     .subscribe(post => {
  //      // this.post = post;
  //     }, error => {
  //       // Handle error
  //     });
  // }

  // getPostsByUser(username: string): void {
  //   this.postService.getPostsByUser(username)
  //     .subscribe(post => {
  //       //this.post = post;
  //     }, error => {
  //       // Handle error
  //     });
  // }

  // deletePost(postId: number): void {
  //   this.postService.deletePost(postId)
  //     .subscribe(response => {
  //       // Handle successful post deletion
  //     }, error => {
  //       // Handle error
  //     });
  // }

  // updatePost(postId: number, post: any): void {
  //   this.postService.updatePost(postId, post)
  //     .subscribe(response => {
  //       // Handle successful post update
  //     }, error => {
  //       // Handle error
  //     });
  // }
}
