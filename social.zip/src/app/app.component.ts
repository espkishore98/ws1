import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'social-media-app';


  ngOnInit() {
    let docTitle = document.title;
    window.addEventListener("blur", () => {
      document.title = "Come Back :(";
    });

    window.addEventListener("focus", () => {
      document.title = docTitle;
    });
  }

}
