import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';
import {Router} from '@angular/router';
import { Post } from 'src/models/post.model';
import { User } from 'src/models/user.model';
import { PostService } from 'src/services/post.service';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css']
})
export class AddPostComponent implements OnInit {
//bloguser =this.loginService.eemail
  bloguser =''
  addPostForm: FormGroup;
  postPayload: Post;

  title = new FormControl('');
  body = new FormControl('');

  constructor(private postService: PostService, private router: Router, private userService : UserService) {
    this.addPostForm = new FormGroup({
      title: this.title,
      body: this.body
    });
    this.postPayload = {
      id:0,
      content: '',
      user: new User()
    };


  }
  postUsername = this.userService.postUsername
  ngOnInit() {
    console.log("postusernmae"+this.postUsername)
  }
  addPost() {
    this.postPayload.user.id= this.userService.userId
    this.postPayload.content=  this.addPostForm.get('body')?.value
    this.postService.savePost(this.postPayload).subscribe(data => {
      this.router.navigateByUrl('/home');
    }, error => {
      console.log('Failure Response');
    })
  }
}
