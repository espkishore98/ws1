import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class LikeService {
  private baseUrl = mainUrl+'/api/likes';

  constructor(private http: HttpClient) { }

  createPostLike(like: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, like);
  }

  getPostLikeById(likeId: number): Observable<any> {
    const url = `${this.baseUrl}/${likeId}`;
    return this.http.get<any>(url);
  }

  deletePostLike(likeId: number): Observable<any> {
    const url = `${this.baseUrl}/${likeId}`;
    return this.http.delete<any>(url);
  }
}
