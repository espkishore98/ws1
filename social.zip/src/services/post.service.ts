import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private baseUrl = mainUrl+'/api/posts';

  constructor(private http: HttpClient) { }

  savePost(post: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, post);
  }

  getAllPosts(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  getPostsByUser(username: string): Observable<any[]> {
    const url = `${this.baseUrl}/user/${username}`;
    return this.http.get<any[]>(url);
  }

  deletePost(postId: number): Observable<any> {
    const url = `${this.baseUrl}/${postId}`;
    return this.http.delete<any>(url);
  }

  updatePost(postId: number, post: any): Observable<any> {
    const url = `${this.baseUrl}/${postId}`;
    return this.http.put<any>(url, post);
  }
}
