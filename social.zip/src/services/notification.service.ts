import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private baseUrl = mainUrl+'/api/notifications';

  constructor(private http: HttpClient) { }

  createNotification(notification: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, notification);
  }

  getNotificationById(notificationId: number): Observable<any> {
    const url = `${this.baseUrl}/${notificationId}`;
    return this.http.get<any>(url);
  }

  getNotificationsByUserId(userId: number): Observable<any[]> {
    const url = `${this.baseUrl}/user/${userId}`;
    return this.http.get<any[]>(url);
  }

  deleteNotification(notificationId: number): Observable<any> {
    const url = `${this.baseUrl}/${notificationId}`;
    return this.http.delete<any>(url);
  }

  markNotificationAsRead(notificationId: number): Observable<any> {
    const url = `${this.baseUrl}/${notificationId}/read`;
    return this.http.put<any>(url, null);
  }
}
