import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private baseUrl = mainUrl+'/api/profiles';

  constructor(private http: HttpClient) { }

  getProfile(profileId: number): Observable<any> {
    const url = `${this.baseUrl}/${profileId}`;
    return this.http.get<any>(url);
  }

  createProfile(profile: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, profile);
  }

  updateProfile(profileId: number, profile: any): Observable<any> {
    const url = `${this.baseUrl}/${profileId}`;
    return this.http.put<any>(url, profile);
  }

  deleteProfile(profileId: number): Observable<any> {
    const url = `${this.baseUrl}/${profileId}`;
    return this.http.delete<any>(url);
  }
}
