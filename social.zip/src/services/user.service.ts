import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from 'src/environments/environment';

const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private baseUrl = mainUrl+'/api/users';
  userId!: number;
  postUsername!:String;
  constructor(private http: HttpClient) { }

  saveUser(user: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, user);
  }

  getUser(user: any): Observable<any> {
    const url = `${this.baseUrl}/login`;
    console.log(url)
    return this.http.post<any>(url, user).pipe(
      tap(response => {
        this.userId = response.id;
        this.postUsername= response.username;
        console.log('User ID:', this.userId);
      }));
  }

  getAllUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  getUserByUsername(username: string): Observable<any> {
    const url = `${this.baseUrl}/${username}`;
    return this.http.get<any>(url);
  }

  deleteUser(userId: number): Observable<any> {
    const url = `${this.baseUrl}/${userId}`;
    return this.http.delete<any>(url);
  }
}
