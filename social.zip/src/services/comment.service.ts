import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private baseUrl = mainUrl+'/api/comments';

  constructor(private http: HttpClient) { }

  createComment(comment: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, comment);
  }

  getCommentById(commentId: number): Observable<any> {
    const url = `${this.baseUrl}/${commentId}`;
    return this.http.get<any>(url);
  }

  deleteComment(commentId: number): Observable<any> {
    const url = `${this.baseUrl}/${commentId}`;
    return this.http.delete<any>(url);
  }
}
