import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl
@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private baseUrl = mainUrl+'/api/chats';

  constructor(private http: HttpClient) { }

  createChat(chat: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, chat);
  }

  getChatMessages(chatId: number): Observable<any> {
    const url = `${this.baseUrl}/${chatId}/messages`;
    return this.http.get<any>(url);
  }

  sendChatMessage(chatId: number, message: any): Observable<any> {
    const url = `${this.baseUrl}/${chatId}/messages`;
    return this.http.post<any>(url, message);
  }

  deleteChatMessage(chatId: number, messageId: number): Observable<any> {
    const url = `${this.baseUrl}/${chatId}/messages/${messageId}`;
    return this.http.delete<any>(url);
  }
}
