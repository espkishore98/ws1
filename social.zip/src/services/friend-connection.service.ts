import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
const mainUrl = environment.mainUrl

@Injectable({
  providedIn: 'root'
})
export class FriendConnectionService {
  private baseUrl = mainUrl+'/api/friendConnections';

  constructor(private http: HttpClient) { }

  createFriendConnection(userId: number, friendId: number): Observable<any> {
    const params = { userId: userId.toString(), friendId: friendId.toString() };
    return this.http.post<any>(this.baseUrl, null, { params });
  }

  deleteFriendConnection(id: number): Observable<any> {
    const url = `${this.baseUrl}/${id}`;
    return this.http.delete<any>(url);
  }

  getFriendCount(userId: number): Observable<number> {
    const url = `${this.baseUrl}/users/${userId}/friends/count`;
    return this.http.get<number>(url);
  }

  getFriends(userId: number): Observable<string[]> {
    const url = `${this.baseUrl}/users/${userId}/friends`;
    return this.http.get<string[]>(url);
  }
}
