export const environment = {
  production: false,
  mainUrl : 'http://localhost:2022'
};
