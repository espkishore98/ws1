import { User } from './user.model';

export interface Chat {
  id: number;
  user: User;
  friend: User;
}
