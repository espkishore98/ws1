import { User } from './user.model';

export interface FriendConnection {
  id: number;
  user: User;
  friend: User;
}
