import { User } from './user.model';

export interface Notification {
  id: number;
  user: User;
  message: string;
  read: boolean;
  createdAt: Date;
}
