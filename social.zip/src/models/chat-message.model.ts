import { Chat } from './chat.model';
import { Notification } from './notification.model';

export interface ChatMessage {
  id: number;
  chat: Chat;
  sender: string;
  receiver: string;
  messageContent: string;
  timestamp: Date;
  notification: Notification;
}
