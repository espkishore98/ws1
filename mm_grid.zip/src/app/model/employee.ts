export class Employee {

  id: number = 0;
name: string = '';
emailId: string='';
designation: string='';
 constructor(){

 }

}
