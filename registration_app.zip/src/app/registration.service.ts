import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  registrationUserFormRemote(user: User) {
    throw new Error('Method not implemented.');
  }

  constructor(private _http:HttpClient) { }

  public loginUserFormRemote(user:User):Observable<any>{
    return this._http.post<any>("http://localhost:8080/login",user);

  }

  public registerUserFormRemote(user:User):Observable<any>{
    return this._http.post<any>("http://localhost:8080/register",user);

  }

}

 