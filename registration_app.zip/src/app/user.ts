export class User {

    id: number = 0;
  email: string = '';
  name: string = '';
  password: string = '';
   constructor(){}
   
}
