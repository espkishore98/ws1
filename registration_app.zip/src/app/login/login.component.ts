import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  otp: string | undefined;
  showOtpComponent = true;
  msg='';
  imagePath ='https://wallpapercave.com/w/wp9764031'
  randNumber = Math.random() * 1000;

@ViewChild("ngOtpInput", { static: false }) ngOtpInput: any; config = { allowNumbersOnly: true, length: 4, isPasswordInput: false, disableAutoFocus: false, placeholder: "*", inputStyles: { width: "50px", height: "50px", }, };
 user=new User();
  constructor(private _service:RegistrationService,private _router:Router){

  }

  ngOnInit() {

  }
  loginUser(){
    console.log(this.user)
    this._service.loginUserFormRemote(this.user).subscribe(
    data =>{

      console.log("response received")
      this._router.navigate(['/loginsuccess'])

    } ,
    error =>{
      console.log("exception occure");
      this.msg="Bad credentials,please enter valid email and password";

    }

    )
  }
  gotoRegistration(){
    this._router.navigate(['/registration'])
  }




// OTP Code
// onOtpChange(otp: string)
// {
//    this.otp = otp;
//    // When all 4 digits are filled,
//    //trigger OTP validation method
//    if (otp.length == 4) { this.validateOtp();
//    }
//   }
//     setVal(val: any)
//      {
//        this.ngOtpInput.setValue(val);
//        }
//         onConfigChange() {
//            this.showOtpComponent = false;
//             this.otp = '';
//              setTimeout(() =>
//             {
//               this.showOtpComponent = true;
//              }, 0);
//              } validateOtp()
//              {
//               //code
//               const data = JSON.stringify({
//                 personalizations: [
//                   {
//                     to: [
//                       {
//                         email: this.user.email
//                       }
//                     ],
//                     subject: 'OTP for Login!'
//                   }
//                 ],
//                 from: {
//                   email: 'sairampasupuleti11@gmail.com'
//                 },
//                 content: [
//                   {
//                     type: 'text/plain',
//                     value: this.randNumber
//                   }
//                 ]
//               });

//               const xhr = new XMLHttpRequest();
//               xhr.withCredentials = true;

//               xhr.addEventListener('readystatechange', function () {
//                 if (this.readyState === this.DONE) {
//                   console.log(this.responseText);
//                 }
//               });

//               xhr.open('POST', 'https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send');
//               xhr.setRequestHeader('content-type', 'application/json');
//               xhr.setRequestHeader('X-RapidAPI-Key', '3fefd560f9msh54db1a246056cbfp1d1487jsn11a9c6c91802');
//               xhr.setRequestHeader('X-RapidAPI-Host', 'rapidprod-sendgrid-v1.p.rapidapi.com');

//               xhr.send(data);

//               // write your logic here to validate it, you can integrate sms API here if you want
//             }


onOtpRequest()
{
 //code
 const data = JSON.stringify({
   personalizations: [
     {
       to: [
         {
           email: this.user.email
         }
       ],
       subject: 'OTP for Login!'
     }
   ],
   from: {
     email: 'sairampasupuleti11@gmail.com'
   },
   content: [
     {
       type: 'text/plain',
       value: this.randNumber
     }
   ]
 });

 const xhr = new XMLHttpRequest();
 xhr.withCredentials = true;

 xhr.addEventListener('readystatechange', function () {
   if (this.readyState === this.DONE) {
     console.log(this.responseText);
   }
 });

 xhr.open('POST', 'https://rapidprod-sendgrid-v1.p.rapidapi.com/mail/send');
 xhr.setRequestHeader('content-type', 'application/json');
 xhr.setRequestHeader('X-RapidAPI-Key', '3fefd560f9msh54db1a246056cbfp1d1487jsn11a9c6c91802');
 xhr.setRequestHeader('X-RapidAPI-Host', 'rapidprod-sendgrid-v1.p.rapidapi.com');

 xhr.send(data);

 // write your logic here to validate it, you can integrate sms API here if you want
}



}



