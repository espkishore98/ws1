import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  msg='';
 user=new User();
  constructor(private _service:RegistrationService,private _router:Router){

  }

  ngOnInit() {
  }
  onSubmit(){
    console.log(this.user)
    this._service.registerUserFormRemote(this.user).subscribe(
    data =>{
      
      console.log("response received")
      this._router.navigate(['/login'])

    } ,
    error =>{
      console.log("exception occure");
      this.msg="Bad credentials,please enter valid email and password";

    }
    
    )
  }
  gotoLogin(){
     this._router.navigate(['/login'])
   }

}
